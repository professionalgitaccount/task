<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'check');

/** MySQL database username */
define('DB_USER', 'check');

/** MySQL database password */
define('DB_PASSWORD', 'check');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'Y2!/)H}vl_) ]d9-;JRe[2-3k3(Uy6=K$nFo2BJ6[,AJS(9V>$&1JAdGP#n8+e{Y');
define('SECURE_AUTH_KEY',  '5ljL_s)m<%A(&.dnz1w0jLI&XbCc9o0k sjIC6sH[vG6)ai0MCCV>Vuk-t&/2G|/');
define('LOGGED_IN_KEY',    '-Uz8s}LuI[#:kB2i]m$277)JsY,`aMV2n}/3zCjznu-L+0BAQ:+7(Zr!kE3O!JV5');
define('NONCE_KEY',        '_@21J*!}Pg&=z%[t0qZXeY23!X%2%F1`Ft_6,=B|alh(/dYZXuSh4~GXN9#+e],<');
define('AUTH_SALT',        'Vuf>mjiMEsa.{o?0T}2D,Cev?0~ul;OX>[zOY?X`6>ea:#y-~bv5&1L:6^8^&;gm');
define('SECURE_AUTH_SALT', 'qB +]+>4$`NVGxyE18}N.PCV&|g]9E!Uyl}f|-}8r> Chx&^Yv|*(g>QG@N3$PrV');
define('LOGGED_IN_SALT',   '<,Ob^-}P*7m/5A$Rj&^0=k8M(_pLZm^WYjjf9 jsxE bBl[3tg7#=c!`_>n`.`OR');
define('NONCE_SALT',       'Jtl^t,}l!aQT6|61Nkmb%o+q!&@Hn1EA->F7O>hn>M3mc3+}<;xX.?nNKBshqBkA');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
